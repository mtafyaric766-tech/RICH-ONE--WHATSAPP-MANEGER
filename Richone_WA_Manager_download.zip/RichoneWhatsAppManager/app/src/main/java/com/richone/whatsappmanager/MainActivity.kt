package com.richone.whatsappmanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

private val RichRed = Color(0xFFD71920)
private val Ink = Color(0xFF202020)

data class SavedGroup(val name: String, val link: String)
data class SavedAd(val title: String, val body: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RichoneApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RichoneApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("richone_data", 0) }

    fun loadGroups(): List<SavedGroup> {
        val arr = JSONArray(prefs.getString("groups", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it); SavedGroup(o.optString("name"), o.optString("link"))
        }
    }
    fun loadAds(): List<SavedAd> {
        val arr = JSONArray(prefs.getString("ads", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it); SavedAd(o.optString("title"), o.optString("body"))
        }
    }
    var groups by remember { mutableStateOf(loadGroups()) }
    var ads by remember { mutableStateOf(loadAds()) }
    var tab by remember { mutableStateOf("Home") }
    var groupName by remember { mutableStateOf("") }
    var groupLink by remember { mutableStateOf("") }
    var adTitle by remember { mutableStateOf("") }
    var adBody by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }

    fun saveGroups(list: List<SavedGroup>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("name", it.name).put("link", it.link)) }
        prefs.edit().putString("groups", a.toString()).apply()
        groups = list
    }
    fun saveAds(list: List<SavedAd>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("title", it.title).put("body", it.body)) }
        prefs.edit().putString("ads", a.toString()).apply()
        ads = list
    }

    MaterialTheme(
        colorScheme = lightColorScheme(primary = RichRed, onPrimary = Color.White,
            secondary = Ink, background = Color(0xFFF7F7F7), surface = Color.White)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("RICHONE", color = RichRed, fontWeight = FontWeight.Black)
                            Text("WHATSAPP MANAGER", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("Home", "Groups", "Ads", "History").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Text(when(item) { "Home" -> "⌂"; "Groups" -> "◎"; "Ads" -> "✎"; else -> "◷" }) },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (notice.isNotBlank()) {
                    Text(notice, color = RichRed, style = MaterialTheme.typography.bodySmall)
                }
                when (tab) {
                    "Home" -> {
                        Text("Welcome to your advertising workspace.", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatCard("Saved groups", groups.size.toString(), Modifier.weight(1f))
                            StatCard("Saved ads", ads.size.toString(), Modifier.weight(1f))
                        }
                        Text("Quick actions", fontWeight = FontWeight.Bold)
                        Button(onClick = { tab = "Groups" }, modifier = Modifier.fillMaxWidth()) { Text("Manage WhatsApp groups") }
                        Button(onClick = { tab = "Ads" }, modifier = Modifier.fillMaxWidth()) { Text("Create an advertisement") }
                        OutlinedButton(onClick = {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"))
                            context.startActivity(intent)
                        }, modifier = Modifier.fillMaxWidth()) { Text("Open WhatsApp") }
                        Text("Sharing is always reviewed and sent by you inside WhatsApp.", style = MaterialTheme.typography.bodySmall)
                    }
                    "Groups" -> {
                        Text("My WhatsApp groups", style = MaterialTheme.typography.titleLarge)
                        OutlinedTextField(groupName, { groupName = it }, label = { Text("Group name") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(groupLink, { groupLink = it }, label = { Text("Invitation link (https://chat.whatsapp.com/...)") }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            if (groupName.isBlank() || !groupLink.startsWith("https://chat.whatsapp.com/")) {
                                notice = "Enter a group name and a valid WhatsApp invitation link."
                            } else {
                                saveGroups(groups + SavedGroup(groupName.trim(), groupLink.trim()))
                                groupName = ""; groupLink = ""; notice = "Group saved."
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Save group") }
                        groups.forEachIndexed { index, g ->
                            Card {
                                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(g.name, fontWeight = FontWeight.Bold)
                                    Text(g.link, style = MaterialTheme.typography.bodySmall)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = {
                                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(g.link)))
                                        }) { Text("Open invite") }
                                        TextButton(onClick = { saveGroups(groups.filterIndexed { i, _ -> i != index }); notice = "Group removed." }) { Text("Delete") }
                                    }
                                }
                            }
                        }
                        if (groups.isEmpty()) Text("No groups saved yet. Add your first invitation link above.")
                    }
                    "Ads" -> {
                        Text("Advertisement creator", style = MaterialTheme.typography.titleLarge)
                        OutlinedTextField(adTitle, { adTitle = it }, label = { Text("Ad title / service") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(adBody, { adBody = it }, label = { Text("Advertisement in Kiswahili") }, modifier = Modifier.fillMaxWidth(), minLines = 5)
                        OutlinedButton(onClick = {
                            val service = adTitle.ifBlank { "HUDUMA ZETU" }
                            adBody = "🔥 $service\n\nUnahitaji huduma hii? RICHONE DIGITAL SERVICES tupo tayari kukuhudumia.\n\n📞 Wasiliana nasi: 0627383106 / 0764654948"
                        }, modifier = Modifier.fillMaxWidth()) { Text("Generate a sample Swahili ad") }
                        Button(onClick = {
                            if (adTitle.isBlank() || adBody.isBlank()) notice = "Add an ad title and message first."
                            else {
                                saveAds(ads + SavedAd(adTitle.trim(), adBody.trim()))
                                adTitle = ""; adBody = ""; notice = "Advertisement saved."
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Save advertisement") }
                        Text("Saved advertisements", fontWeight = FontWeight.Bold)
                        ads.forEachIndexed { index, ad ->
                            Card {
                                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(ad.title, fontWeight = FontWeight.Bold)
                                    Text(ad.body)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(onClick = {
                                            val send = Intent(Intent.ACTION_SEND).apply {
                                                type = "text/plain"; putExtra(Intent.EXTRA_TEXT, ad.body)
                                            }
                                            context.startActivity(Intent.createChooser(send, "Review and share using WhatsApp"))
                                        }) { Text("Share") }
                                        TextButton(onClick = { saveAds(ads.filterIndexed { i, _ -> i != index }); notice = "Advertisement deleted." }) { Text("Delete") }
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        Text("Advertising history", style = MaterialTheme.typography.titleLarge)
                        Text("Your saved advertisements are shown below. This starter version records saved ads, not confirmed WhatsApp deliveries.")
                        ads.forEach { ad ->
                            Card { Column(Modifier.padding(12.dp)) { Text(ad.title, fontWeight = FontWeight.Bold); Text(ad.body) } }
                        }
                        if (ads.isEmpty()) Text("No saved advertisements yet.")
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(value, style = MaterialTheme.typography.headlineMedium, color = RichRed, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.bodySmall)
        }
    }
}
