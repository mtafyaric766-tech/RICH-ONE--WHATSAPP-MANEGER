# RICHONE WHATSAPP MANAGER — Android starter project

## Included in this first prototype
- English app navigation and labels
- Red-and-white Richone styling
- Save and delete WhatsApp group invitation links locally on the phone
- Open a saved invitation link in WhatsApp/browser
- Create, save, delete, and share Swahili advertisements
- Android share chooser: choose WhatsApp, review the destination, and press Send yourself
- Basic local sample-ad templates (not a connected AI service)

## Important limitations
- The ad generator currently uses local templates. A real AI writer needs a secure backend/API.
- WhatsApp does not provide an official public API for silently joining ordinary groups or bulk-posting to them. This app does not auto-join or auto-send.
- Sharing through Android does not guarantee a particular group is selected. You choose the destination in WhatsApp.
- Saved-ad history does not verify message delivery.
- This project has not yet been compiled or tested on a physical phone. An APK must be built and tested before it can be called install-ready.

## Build an APK using GitHub Actions (phone-friendly cloud build)
1. Create/sign in to a GitHub account in your phone browser.
2. Create a new repository named `RichoneWhatsAppManager`.
3. Upload the contents of this project ZIP to the repository (upload the files and folders, not the ZIP as one file). Ensure `.github/workflows/build-apk.yml` is included.
4. Open the repository's **Actions** tab and select **Build Android APK**. If needed, tap **Run workflow**.
5. Wait for the workflow to finish successfully. Open its run, scroll to **Artifacts**, and download `RichoneWhatsAppManager-debug-apk`.
6. Extract the downloaded artifact ZIP. Install `app-debug.apk` on the TECNO phone. Android may ask you to allow installation from that browser/files app; only proceed if the APK came from your own successful GitHub build.

The workflow builds a debug APK with Java 17 and Gradle 8.9. It does not sign a Play Store release APK.
